

/***************************** Include Files *******************************/
#include "Speck_Block_Cipher.h"

/************************** Function Definitions ***************************/
