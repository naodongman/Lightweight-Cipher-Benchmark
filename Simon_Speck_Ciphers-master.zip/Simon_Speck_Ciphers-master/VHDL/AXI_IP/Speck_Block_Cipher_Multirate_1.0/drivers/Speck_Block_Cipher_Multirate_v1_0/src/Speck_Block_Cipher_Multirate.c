

/***************************** Include Files *******************************/
#include "Speck_Block_Cipher_Multirate.h"

/************************** Function Definitions ***************************/
