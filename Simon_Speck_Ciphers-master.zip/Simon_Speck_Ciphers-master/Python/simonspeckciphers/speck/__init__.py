# -*- coding: utf-8 -*-

"""Top-level package for Speck"""
from .speck import SpeckCipher
__author__ = """Michael Calvin McCoy"""
__email__ = 'calvin.mccoy@protonmail.com'
__version__ = '1.0.0'
