# Changelog

## [v1.1.0] - 2019-11-01
### Added
- Automatic file detection for the build system.
- Unity test framework.

## [v1.0.0] - 2018-11-30
- Initial release
